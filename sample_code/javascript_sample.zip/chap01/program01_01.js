// program01_01.js: Hello world!
var x;
x = 3;
console.log("x=",x);
x = x + 100;
console.log("x=",x);