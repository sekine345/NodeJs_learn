// program02_01.js: Hello world!
console.log("Hello World!");